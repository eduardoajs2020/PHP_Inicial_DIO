#ifndef __dbaseh__
#define __dbaseh__

#ifndef __htmlstreamh__
  #include "htmlstream.h"
#endif

#include <string>
#include <iostream>

class DBaseBase {
public:
  virtual void Disconnect(HTMLStream &stream,HTMLStream::iterator cur,
      const ParamMap& params) =0;
  virtual void Query(HTMLStream &stream,HTMLStream::iterator cur,
      const string& entryproc,const ParamMap& params,bool is_discard, bool is_assign)=0;
};

#endif
