#ifndef __imgstoreh__
#define __imgstoreh__

#include <map>
#include <string>

class IMGStore{
public:
  static bool GetSize(const string& fname,int& width,int& height);
private:
  class Image{
  public:
    Image(int width,int height,bool OK):m_OK(OK),m_width(width),
      m_height(height){}
    Image(){}
    bool m_OK;
    int m_width,m_height;
  };
  static map<string,Image> m_imgMap;
};

#endif
