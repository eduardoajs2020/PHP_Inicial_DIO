#ifndef __pluginh__
  #include "../plugin.h"
#endif
#ifndef __errorh__
  #include "../error.h"
#endif
#ifndef __polytypeh__
  #include "../polytype.h"
#endif

#include <string>
#include <vector>

class dsoEcommerceMod :public Plugin{
public:
  dsoEcommerceMod();
  virtual void Init();
private:
  static void VALIDCARDNUM(__HITOPFUNC__);
};

static dsoEcommerceMod initmodule;

dsoEcommerceMod::dsoEcommerceMod() {
  RegisterPlugin("ecommerce",1);
}

void dsoEcommerceMod::Init(){
  Plugin::RegisterFunction("VALIDCARDNUM",&dsoEcommerceMod::VALIDCARDNUM);
}

void dsoEcommerceMod::VALIDCARDNUM(__HITOPFUNC__){
  if(params.size()!=0) Error(cur,"VALIDCARDNUM",e_ParamNone);
  string::reverse_iterator pos;
  int mult=1,sum=0,prod,digits=0;
  for(pos=data.AsString().rbegin();pos!=data.AsString().rend();++pos){
    if(isdigit(*pos)){
      ++digits;
      prod=(*pos-'0')*mult;
      sum+=(prod%10)+(prod/10);
      mult=3-mult;
    }
  }
  if((digits>12)&&((sum%10)==0)) data="1"; else data="0";
}
