#ifndef __pluginh__
  #include "../plugin.h"
#endif

#include <string>

class dsoDBCoreMod :public Plugin{
public:
  dsoDBCoreMod();
  virtual void Init();
private:
  //Core methods are in DBManager
};

static dsoDBCoreMod initmodule;

dsoDBCoreMod::dsoDBCoreMod() {
  RegisterPlugin(string("db"),1);
}

void dsoDBCoreMod::Init(){
  RegisterCommand("CONNECT",&DBManager::Connect);
  RegisterCommand("QUERY",&DBManager::Query);
  RegisterCommand("DISCONNECT",&DBManager::Disconnect);
}
