#ifndef __plugins_calendarh__
#define __plugins_calendarh__

#ifndef __htmlstreamh__
  #include "../htmlstream.h"
#endif
#ifndef __pluginh__
  #include "../plugin.h"
#endif

class dsoCalMod :public Plugin{
public:
  dsoCalMod();
  virtual void Init();
  static HTMLStream::iterator MONTH(HTMLStream& stream,HTMLStream::iterator Cur,const ParamMap& paramMap,const string& tag);
private:
  static void DefaultMonPreMon(HTMLStream& stream,HTMLStream::iterator Cur,int month,int year);
  static void DefaultMonPreWeek(HTMLStream& stream,HTMLStream::iterator Cur,int weeknum,int blanks);
  static void DefaultMonPostWeek(HTMLStream& stream,HTMLStream::iterator Cur,int weeknum,int blanks);
  static void DefaultMonPostMon(HTMLStream& stream,HTMLStream::iterator Cur,int month,int year);
  static void DefaultMonDay(HTMLStream& stream,HTMLStream::iterator Cur,int dow,int day);
  static void DefaultMonBlank(HTMLStream& stream,HTMLStream::iterator Cur,int dow);
};

#endif
