#ifndef __pngh__
#define __pngh__

#include <cstdio>

class PNG{
public:
  static bool GetSize(FILE *file, int& height, int& width);
private:
  static bool IsA(FILE *file);
};

#endif

