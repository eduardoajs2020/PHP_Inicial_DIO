#ifndef __hitopcoreh__
#define __hitopcoreh__

#include <map>
#include <string>

class tm;
class HTMLStream;

extern const string g_version;
extern const string g_dateISO;
extern const string g_years;
extern const bool g_isXML;
extern const bool g_isHTML;
extern string g_contentType;

extern multimap<string,string> g_httpHeader;
extern string g_statusHeader;

extern string replicate(const string& a,int n);
extern void DoVars(HTMLStream *Main);
extern bool ParseArgs(int argn,char* argc[],string& inFile,string& outFile);

#endif
