#ifndef __defstoreh__
#define __defstoreh__

#ifndef __tokenmaph__
  #include "tokenmap.h"
#endif
#ifndef __htmlstreamh__
  #include "htmlstream.h"
#endif

#include <map>
#include <string>

class HTML;

class DEFStore{
public:
  static bool IsValidName(const string& name);
  static bool Exists(TokenMap::Token token);
  static HTMLStream* Find(TokenMap::Token token);
  static bool Set(TokenMap::Token token,HTMLStream::iterator first,
    HTMLStream::iterator last);
  static void Delete(TokenMap::Token token);
private:
  static map<TokenMap::Token,HTMLStream> m_store;
};

#endif

