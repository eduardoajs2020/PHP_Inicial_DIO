#ifndef __tables_tablesh__
#define __tables_tablesh__

#include "elements.h"

extern void InitTables();

#endif
