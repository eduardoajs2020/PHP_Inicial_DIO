#ifndef __tables_entitiesh__
#define __tables_entitiesh__

#include <map>
#include <string>

class Entities{
public:
  static string Escape(const string& data);
  static string Unescape(const string& data);
private:
  static void InitEntities();
  static map<char,string> m_entityMap;
  static bool m_filled;
};

#endif
