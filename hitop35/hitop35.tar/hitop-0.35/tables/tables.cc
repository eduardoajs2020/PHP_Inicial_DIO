#include "tables.h"
#include "../hitopcore.h"

void InitTables(){
  if(!g_isXML&&g_isHTML) InitElements();
}
