#ifndef __tables_elementsh__
#define __tables_elementsh__

#ifndef __tokenmaph__
  #include "../tokenmap.h"
#endif
#include <map>

enum HTMLFlags {Before=1,After=2,Container=4};

extern map<TokenMap::Token,int> g_HTMLFlags;
extern void InitElements();

#endif
