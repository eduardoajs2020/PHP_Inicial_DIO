#ifndef __jpegh__
#define __jpegh__

#include <cstdio>

class JPEG{
public:
  static bool GetSize(FILE *file, int& height, int& width);
private:
  static bool IsA(FILE *file);
};

#endif
