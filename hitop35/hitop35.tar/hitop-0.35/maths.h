#ifndef __mathsh__
#define __mathsh__

#include <string>

string evaluate(const string& expression);

#endif
