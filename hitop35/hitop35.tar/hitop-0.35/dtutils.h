#ifndef __dtutilsh__
#define __dtutilsh__

#include <string>

extern bool isAbsolute(const string& s);
extern string PathPart(string fname);
extern string IToS(int val);
extern string FToS(float val);
extern string FilePart(string fname);
extern string escape(string data);
extern string unescape(string urlEncoded) ;
//extern string RemoveQuotes(const string& text);
extern int global_replace(string& st,const string& find,const string& rep);
extern string EscapeSignificant(string text);

#endif
