#ifndef __gifh__
#define __gifh__

#include <cstdio>

class GIF{
public:
  static bool GetSize(FILE *file, int& height, int& width);
private:
  static bool IsA(FILE *file);
};

#endif
