#ifndef __pluginmgrh__
#define __pluginmgrh__

#ifndef __htmlstreamh__
  #include "htmlstream.h"
#endif

#include <string>

/* dynamically loaded plugin handling functions. */

class PluginManager {
public:
  static void Load(HTMLStream::iterator cur,const string& extensionname,const string& fnnamespace,int version);
  static string s_loadpath;
  static void Init();
private:
  static bool StaticLoad(HTMLStream::iterator cur,const string& extensionname,const string& fnnamespace,int version);
  static bool DLLoad(HTMLStream::iterator cur,string extensionname,const string& fnnamespace,int version);
};

#endif // ndef __pluginmgrh__
