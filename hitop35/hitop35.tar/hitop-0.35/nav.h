#ifndef __navh__
#define __navh__

#ifndef __htmlstreamh__
  #include "htmlstream.h"
#endif
#ifndef __navstoreh__
  #include "navstore.h"
#endif
#ifndef __tokenmaph__
  #include "tokenmap.h"
#endif

#include <string>

class ParamMap;

class Nav {
  NavStore m_data;
public:
  void Load(HTMLStream& stream,HTMLStream::iterator cur,
    const string& filename,const string& URLPath,
    NavStore::OutputFormat format);
  void Set(HTMLStream& stream,HTMLStream::iterator cur,
    const string& data,const string& URLPath,
    NavStore::OutputFormat format);
  void Execute(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,NavStore::OutputFormat format,
    TokenMap::Token preToken,TokenMap::Token entryToken,TokenMap::Token
    postToken,int from=0,int to=-1);
};

#endif
