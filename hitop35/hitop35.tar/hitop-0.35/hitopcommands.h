#ifndef __hitopcommandsh__
#define __hitopcommandsh__

#ifndef __htmlstreamh__
  #include "htmlstream.h"
#endif
#ifndef __tokenmaph__
  #include "tokenmap.h"
#endif

#include <string>

class HitopCommands{
public:
  static HTMLStream::iterator IF(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator SET(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator GET(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator FILE(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator DEF(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator UNDEF(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator IMG(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator NAV(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static void ProcCallInline(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static void ProcCallByNum(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,TokenMap::Token token);
  static void UserEngine(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator USER(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator ForEngine(HTMLStream& stream,
    HTMLStream::iterator cur,const ParamMap& paramMap,TokenMap::Token
    entryToken,int step);
  static HTMLStream::iterator FOREACH(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator FOR(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator HITOP(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator DEBUG(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator RAWHEADER(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator UNSET(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator REQUIRES(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator IMPOSSIBLE(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator COOKIE(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static HTMLStream::iterator COMMENT(HTMLStream& stream,HTMLStream::iterator cur,
    const ParamMap& paramMap,const string& tag);
  static void Init();
};

#endif
